# ElectronJS
A simple Hello world application using ElectronJS. Download and install node.js by going through this link https://nodejs.org/en/download/.


To install electron on windows/MAC/linux, run the electronInstall.bat using command prompt shown as

cd Drive:/path/to/ElectronJSApplication/electronInstall.bat


To run the app, use this command on cmd

cd Drive:/path/to/ElectronJSApplication/electron .

If you want to package the app or create a .exe file of the app, first run the electron-packagerInstall.bat file to install electron-packager package using cmd as

cd Drive:/path/to/ElectronJSApplication/electron-packagerInstall.bat

Then, run packaging.bat file in cmd as

cd Drive:/path/to/ElectronJSApplication/packaging.bat
